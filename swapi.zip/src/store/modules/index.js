/* eslint camelcase: 0 */
import search from './search'

const modules = {
  search
}

export default modules
