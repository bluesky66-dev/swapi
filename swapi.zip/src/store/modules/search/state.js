const state = () => ({
  peopleCount: '',
  peopleArray: [],
  planetArray: [],
  currentPage: 1,
  peopleURL: 'https://swapi.dev/api/people/'
})

export default state
